﻿using UnityEngine;
using System.Collections;

public class Bullet : MonoBehaviour {
    public Tank tank;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

    void OnCollisionEnter2D(Collision2D collision)
    {
        

        if (collision.gameObject != tank.gameObject)
        {
            tank.BulletCollision();

            this.gameObject.SetActive(false);

            bool isBackground = collision.gameObject.name.Contains("Background") || collision.gameObject.name.Contains("ice") || collision.gameObject.name.Contains("water");

            bool isBullet = collision.gameObject.GetComponent<Bullet>() != null;
            if (isBullet)
            {
                return;
            }

            Eagle eagle = collision.gameObject.GetComponent<Eagle>();
            if (eagle != null)
            {
                eagle.Kill();
                return;
            }

            Tank otherTank = collision.gameObject.GetComponent<Tank>();
            if (otherTank != null)
            {
                otherTank.Damage();
                return;
            }
            
            if (!isBackground)
            {
                DestroyObject(collision.gameObject);
            }
            
        }

    }

}
