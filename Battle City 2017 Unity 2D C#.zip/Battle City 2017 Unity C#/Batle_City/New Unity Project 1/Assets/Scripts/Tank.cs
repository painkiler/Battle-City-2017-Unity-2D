﻿using UnityEngine;
using System.Collections;
using System;

public enum TankDirection
{
    None,
    North,
    South,
    West,
    East
}
public class Tank : MonoBehaviour {

    public enum Kind
    {
        Normal,
        Fast,
        Resistant
            

    }

    
        

    public Kind kind = Kind.Normal;

    // Use this for initialization
    public Rigidbody2D myTank;
    public BoxCollider2D myBoxCollider;
    public float moveTime = 0.2f;
    private float inverseMoveTime;
    public LayerMask blockingLayer;
    public GameObject bulletPrefab;
    public float bulletSpeed = 80f;
    public Transform projectileSpawn;
    public int x = 0;
    public int y = 1;
    private bool bullet_was_fired = false;

    private int lives = 1;

    private bool isMoving;

    public AudioClip idleAudio;
    public AudioClip moveAudio;

    public bool isDead = false;
    public float deadTime;

    private Vector3 startPos;

    private AudioSource audioSource;

    void Start () {

        Reset();

        bulletPrefab.SetActive(false);

        audioSource = GetComponent<AudioSource>();
        startPos = this.transform.position;
    }

    public void Reset()
    {
        switch (kind)
        {
            case Kind.Fast:
                {
                    moveTime /= 2;
                    break;
                }

            case Kind.Resistant:
                {
                    lives = 3;
                    moveTime *= 2;
                    break;
                }
        }
        UpdateSpeed();
    }

    public void UpdateSpeed()
    {
        inverseMoveTime = 0.3f / moveTime;
    }

    public void Stop()
    {
        if (isMoving)
        {
            isMoving = false;

            if (audioSource != null && moveAudio != null)
            {
                audioSource.clip = idleAudio;
                audioSource.Play();
            }


        }
    }

    void OnEnable()
    {
        myTank = GetComponent<Rigidbody2D>();
        myBoxCollider = GetComponent<BoxCollider2D>();

    }

    public bool Move (TankDirection dir, out RaycastHit2D hit)
    {
        int xDir, yDir;
        float angle;

        switch (dir)
        {
            case TankDirection.North:
                {
                    xDir = 0;
                    yDir = 1;
                    angle = 0;
                    break;
                }
            case TankDirection.South:
                {
                    xDir = 0;
                    yDir = -1;
                    angle = 180;
                    break;
                }
            case TankDirection.West:
                {
                    xDir = -1;
                    yDir = 0;
                    angle = 90;
                    break;
                }
            default:
                {
                    xDir = 1;
                    yDir = 0;
                    angle = -90;
                    break;
                }

        }

        this.x = xDir;
        this.y = yDir;

        Vector2 start = transform.position;
        Vector2 d = new Vector2(xDir, yDir);
        d.Normalize();
        d *= 0.1f;
        Vector2 end = start + d;
        myBoxCollider.enabled = false;
        hit = Physics2D.Linecast(start, end);
        myBoxCollider.enabled = true;

        transform.rotation = Quaternion.AngleAxis(angle, Vector3.forward);

        var playerTank = GetComponent<TankController>();

        if (hit.transform == null)
        {
            if (audioSource != null && moveAudio != null && !isMoving)
            {
                audioSource.clip = moveAudio;
                audioSource.Play();
            }

            isMoving = true;

            SmoothMovement(end);
            return true;
        }        
        else
        if (playerTank !=null)
        {
            var p = hit.transform.GetComponent<PowerUp>();
            if (p != null)
            {
                var powerup = p.GetKind();
                switch (powerup)
                {
                    case PowerUp.Kind.Life: PlayerTank.lives++; break;
                    case PowerUp.Kind.Freeze: EnemyTank.Freeze(); break;
                    case PowerUp.Kind.Bomb: TankSpawner.Bomb(); break;
                    case PowerUp.Kind.Shield: playerTank.ActivateShield(); break;
                    case PowerUp.Kind.Star: playerTank.Upgrade(); break;
                }

                p.Take();
            }

            Debug.Log("HIT " +hit.transform.name);
        }

        return false;
    }

    protected IEnumerator SmoothMovement(Vector3 end)
    {
        Vector3 newPosition = Vector3.MoveTowards(myTank.position, end, inverseMoveTime * Time.deltaTime);
        myTank.MovePosition(newPosition);
        return null;
    }

    public bool Fire()
    {
        if (bullet_was_fired)
        {
            return false;
        }

        // Create the Bullet from the Bullet Prefab
        //GameObject bulletinstance = Instantiate(bulletPrefab, transform.position, transform.rotation) as GameObject;
        bulletPrefab.SetActive(true);

        bulletPrefab.transform.position = this.transform.position;

        bulletPrefab.GetComponent<Bullet>().tank = this;

        // Add velocity to the bullet
        bulletPrefab.GetComponent<Rigidbody2D>().AddForce(new Vector2(x * bulletSpeed, y * bulletSpeed));

        bullet_was_fired = true;

        // Destroy the bullet after 2 seconds
        //Destroy(bulletinstance, 2.0f);

        return true;
    }

    public void Damage()
    {
        var playerTank = GetComponent<TankController>();
        if (playerTank != null && playerTank.hasShield)
        {
            return;
        }

        lives--;

        if  (lives <= 0)
        {
            Kill();
        }
    }

    public void Kill()
    {
        isDead = true;
        this.gameObject.SetActive(false);
        deadTime = Time.time;
    }

    public void Respawn()
    {
        isDead = false;
        this.gameObject.SetActive(true);
        this.transform.position = startPos;

        Reset();
    }

    public void BulletCollision()
    {
        bullet_was_fired = false;
    }
}
