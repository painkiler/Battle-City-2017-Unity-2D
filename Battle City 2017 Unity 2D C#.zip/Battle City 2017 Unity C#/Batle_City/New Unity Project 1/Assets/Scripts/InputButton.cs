﻿using UnityEngine;
using System.Collections;

public class InputButton : MonoBehaviour
{
    public PlayerKey key;

	// Use this for initialization
	void Start () {
    	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

    public void OnMouseDown()
    {
        //Debug.Log(this.gameObject.name + " Was Clicked.");

        PlayerTank.keys[this.key] = true;
    }


    public void OnMouseUp()
    {
        //Debug.Log(this.gameObject.name + " Was released.");
        PlayerTank.keys[this.key] = false;
    }

}
