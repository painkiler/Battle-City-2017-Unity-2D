﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HiscoreLabel : MonoBehaviour {

    private Text label;

	void Start () {
        label = GetComponent<Text>();
        label.text = "Pontuação final: "+PlayerTank.score.ToString();
	}
	
	void Update () {
        		
	}
}
