﻿using UnityEngine;
using System.Collections;

public class Eagle : MonoBehaviour {

    public bool isDead;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

    public void Kill()
    {
        isDead = true;
    }
}
