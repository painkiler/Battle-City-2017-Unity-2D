﻿using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using System.Collections.Generic;

public enum PlayerKey
{
    Up,
    Down,
    Left,
    Right,
    Fire
}
public class PlayerTank : MonoBehaviour {


    public static Dictionary<PlayerKey, bool> keys = new Dictionary<PlayerKey, bool>();

    public static int lives = 3;


    public static int score = 0;

    public Text label;

    public Tank tank;
    public Eagle eagle;

    private bool isGameOver;
    private float gameOverTime;

    private AudioSource gameoverAudio;


	// Use this for initialization
	void Start () {
        keys[PlayerKey.Down] = false;
        keys[PlayerKey.Up] = false;
        keys[PlayerKey.Left] = false;
        keys[PlayerKey.Right] = false;
        keys[PlayerKey.Fire] = false;
        
        this.gameoverAudio = GetComponent<AudioSource>();

    }
	
	// Update is called once per frame
	void Update () {
        if (isGameOver)
        {
            float delta = Time.time - gameOverTime;

            if (delta>5)
            {
                SceneManager.LoadScene(0);

                lives = 3;
                this.gameObject.SetActive(false);
                return;
            }

            label.text = "Game over";
            return;
        }

        label.text = "Vidas: " + lives.ToString();

        if (eagle.isDead && !isGameOver)
        {
            GameOver();
        }

        if (tank.isDead)
        {
            lives--;
            if (lives>0)
            {
                tank.Respawn();
            }
            else
            if (!isGameOver)
            {
                GameOver();
            }
        }
	}

    private void GameOver()
    {
        isGameOver = true;
        gameOverTime = Time.time;
        gameoverAudio.Play();
    }


}
