﻿using UnityEngine;
using System.Collections;

public class EnemyTank : MonoBehaviour {

    private static bool isFreeze;
    private static float freezeTime;

    public static void Freeze()
    {
        isFreeze = true;
        freezeTime = Time.time + 20;
    }

    float lastAIMove;

    Tank tank;

    private TankDirection currentDirection;

	void Start () {
        tank = GetComponent<Tank>();
	}
	
	// Update is called once per frame
	void Update () {
        if (isFreeze)
        {
            if (Time.time > freezeTime)
            {
                isFreeze = false;
            }
            else
            {
                return;
            }            
        }

        float delta = Time.time - lastAIMove;

        RaycastHit2D hit;

        if (currentDirection != TankDirection.None)
        {
            tank.Move(currentDirection, out hit);
        }

        if (delta>1)
        {
            lastAIMove = Time.time;

            int n = Random.Range(0, 20);
            switch (n)
            {
                case 0:
                    {
                        currentDirection = TankDirection.North;
                        break;
                    }
                case 1:
                    {
                        currentDirection = TankDirection.South;
                        break;
                    }
                case 2:
                    {
                        currentDirection = TankDirection.West;
                        break;
                    }
                case 3:
                    {
                        currentDirection = TankDirection.East;
                        break;
                    }
                default:
                    {
                        if (tank.Fire())
                        {
                            //currentDirection = TankDirection.None;
                            lastAIMove = Time.time - 1;
                        }
                        break;
                    }
            }
        }

    }

    void OnDestroy()
    {

    }
    
}
