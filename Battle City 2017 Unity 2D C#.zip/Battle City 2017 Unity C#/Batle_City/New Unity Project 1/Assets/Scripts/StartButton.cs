﻿using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections;

public class StartButton : MonoBehaviour {

    public void OnMouseDown()
    {
        Debug.Log("start click");
        SceneManager.LoadScene(1);
    }

}
