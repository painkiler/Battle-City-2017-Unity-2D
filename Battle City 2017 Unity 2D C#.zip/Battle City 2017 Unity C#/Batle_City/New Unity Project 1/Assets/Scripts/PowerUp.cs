﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PowerUp : MonoBehaviour {

    public enum Kind
    {
        Bomb,
        Freeze,
        Life,
        Shield,
        ShieldEagle,
        Star
    }

    private Kind kind;

    public Kind GetKind()
    {
        return kind;
    }

    private SpriteRenderer spriteRenderer;
    private BoxCollider2D collider;

    private float lastTime;
    private bool visible;

    private float spawnTime = 3f;

	// Use this for initialization
	void Start () {
        spriteRenderer = GetComponent<SpriteRenderer>();
        collider = GetComponent<BoxCollider2D>();


        Reset();

        ReloadSprite();
    }
	
	// Update is called once per frame
	void Update () {

        spriteRenderer.color = new Color(1, 1, 1, visible ? 1 : 0);

        float delta = Time.time - lastTime;
        if (!visible && delta>=spawnTime)
        {
            this.lastTime = Time.time;
            this.visible = true;
            this.collider.enabled = true;
            this.kind = (Kind)Random.Range(0, 6);

           // this.kind = Kind.Shield;
            ReloadSprite();
        }
    }

    public void Take()
    {
        this.GetComponent<AudioSource>().Play();
        Reset();
    }

    void Reset()
    {
        visible = false;
        this.collider.enabled = false;
        this.lastTime = Time.time;
    }

    void ReloadSprite()
    {
        var sprite = Resources.Load<Sprite>("PowerUps/" + kind.ToString());
        spriteRenderer.sprite = sprite;
    }

}
