﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System.Collections;

public class TankSpawner : MonoBehaviour {

    public Tank[] tanks;
    public Text tankLabel;
    public Text scoreLabel;

    private static TankSpawner instance;

    public int limit = 20;

    private int tankCount = 0;

    private bool levelComplete;

	// Use this for initialization
	void Start () {
        instance = this;
	}


	// Update is called once per frame
	void Update () {
        if (levelComplete)
        {
            return;
        }

        int n = limit - tankCount;
        tankLabel.text = "Tanks: " + n.ToString();

	    for (int i=0; i<tanks.Length; i++)
        {
            if (tanks[i].isDead)
            {
                float delta = Time.time - tanks[i].deadTime;

                if (delta>5)
                {
                    tankCount++;

                    PlayerTank.score += 100;
                    scoreLabel.text = PlayerTank.score.ToString();

                    if (tankCount >= limit)
                    {
                        Debug.Log("Level complete");
                        levelComplete = true;
                        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
                   }
                    else
                    {
                        tanks[i].Respawn();
                    }

                }
                
            }
        }
	}

    private void Bomb2()
    {
        for (int i = 0; i < tanks.Length; i++)
        {
            if (!tanks[i].isDead)
            {
                tanks[i].Kill();
            }

        }
    }

    public static void Bomb()
    {
        instance.Bomb2();
    }

}
