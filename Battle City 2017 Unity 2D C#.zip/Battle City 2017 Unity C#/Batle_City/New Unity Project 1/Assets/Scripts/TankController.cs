﻿using UnityEngine;
using System.Collections;

public class TankController : MonoBehaviour {

    public Tank tank;

    private Transform shield;

    public enum Kind
    {
        Normal,
        Super,
        Mega
    }

    public Kind kind = Kind.Normal;

    private SpriteRenderer spriteRenderer;

    // Use this for initialization
    void Start () {
        this.tank = this.gameObject.GetComponent<Tank>();

        this.shield = this.transform.FindChild("Shield");
        if (this.shield == null)
        {
            
        }
        else
        {
            shield.gameObject.SetActive(false);
        }

        spriteRenderer = GetComponent<SpriteRenderer>();
    }

    void Update()
    {

        RaycastHit2D hit;

        UpdateKeyboard();


        if (PlayerTank.keys[PlayerKey.Right])
        {
            tank.Move( TankDirection.East, out hit);
        }
        else if (PlayerTank.keys[PlayerKey.Left])
        {
            tank.Move(TankDirection.West, out hit);
        }
        else if (PlayerTank.keys[PlayerKey.Up])
        {
            tank.Move(TankDirection.North, out hit);
        }
        else if (PlayerTank.keys[PlayerKey.Down])
        {
            tank.Move(TankDirection.South, out hit);
        }
        else if (PlayerTank.keys[PlayerKey.Fire])
        {
            tank.Fire();

            //print("fire; " + transform.forward);
        }
        else
        {
            tank.Stop();
        }
    }

    private void UpdateKeyboard()
    {
        UpdateInput(KeyCode.LeftArrow, PlayerKey.Left);
        UpdateInput(KeyCode.RightArrow, PlayerKey.Right);
        UpdateInput(KeyCode.DownArrow, PlayerKey.Down);
        UpdateInput(KeyCode.UpArrow, PlayerKey.Up);
        UpdateInput(KeyCode.F, PlayerKey.Fire);
    }

    private void UpdateInput(KeyCode key, PlayerKey pKey)
    {
        if (Input.GetKeyDown(key))
        {
            PlayerTank.keys[pKey] = true;
        }

        if (Input.GetKeyUp(key))
        {
            PlayerTank.keys[pKey] = false;
        }
    }

    public bool hasShield;
    private float shieldTime;

    public void ActivateShield()
    {
        hasShield = true;
        shieldTime = Time.time + 20;
        shield.gameObject.SetActive(true);
    }

    public void Upgrade()
    {
        Tank tank = GetComponent<Tank>();
        switch (kind)
        {
            case Kind.Normal:
                kind = Kind.Super;
                tank.moveTime /= 1.5f;
                tank.UpdateSpeed();
                break;

            case Kind.Super:
                kind = Kind.Mega;
                tank.moveTime /= 2;
                tank.bulletSpeed *= 1.5f;
                tank.UpdateSpeed();
                break;

            default: return;
        }

        ReloadSprite();
    }

    void ReloadSprite()
    {
        var sprite = Resources.Load<Sprite>("Player Tank/" + kind.ToString());
        spriteRenderer.sprite = sprite;
    }

}
